import re
import os
import sys
import traceback

# Let us not register our application under at-spi application list
os.environ ['GTK_MODULES'] = ''

try:
    import pyatspi as atspi, Accessibility
except ImportError:
    import atspi
    import Accessibility

from ldtpcommon import *

class LdtpGui:
    def __init__ (self, registry, cctxt):
        self.cctxt = cctxt
        self.registry = registry

#    def getGuiHandle (cctxt, )
