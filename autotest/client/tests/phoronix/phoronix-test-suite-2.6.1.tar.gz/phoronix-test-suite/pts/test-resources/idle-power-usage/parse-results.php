<?php

echo pts_read_log_file();

?>
