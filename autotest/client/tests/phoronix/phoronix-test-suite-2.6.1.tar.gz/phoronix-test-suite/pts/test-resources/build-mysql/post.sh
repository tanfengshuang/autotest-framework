#!/bin/sh

rm -rf mysql-5.1.30/
