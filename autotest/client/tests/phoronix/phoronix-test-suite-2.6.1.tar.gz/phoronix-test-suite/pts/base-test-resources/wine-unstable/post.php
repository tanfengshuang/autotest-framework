<?php

file_put_contents("pts-test-note", "Wine v1.1.32");

?>

