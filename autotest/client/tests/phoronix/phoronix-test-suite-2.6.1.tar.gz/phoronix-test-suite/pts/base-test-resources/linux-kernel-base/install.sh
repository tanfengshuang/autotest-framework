#!/bin/sh

# Provides linux-2.6.32.tar.bz2
