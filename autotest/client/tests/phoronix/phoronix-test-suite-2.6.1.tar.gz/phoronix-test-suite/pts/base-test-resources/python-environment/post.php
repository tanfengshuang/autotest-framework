<?php

file_put_contents("pts-test-note", "PYTHON_VERSION");

?>

