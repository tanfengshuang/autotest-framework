<?php

file_put_contents("pts-test-note", "JAVA_VERSION");

?>

