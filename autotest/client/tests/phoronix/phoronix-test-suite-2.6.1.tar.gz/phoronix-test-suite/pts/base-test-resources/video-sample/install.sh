#!/bin/sh

tar -xvf pts-trondheim-avi.tar.bz2
tar -xvf pts-sample-playback-1.avi.tar.bz2
tar -xvf Grey.ts.tar.bz2
# mv pts-trondheim-1.avi pts-trondheim.avi
