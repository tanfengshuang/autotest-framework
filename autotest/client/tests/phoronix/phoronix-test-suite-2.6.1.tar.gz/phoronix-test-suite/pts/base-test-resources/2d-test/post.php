<?php

file_put_contents("pts-test-note", "2D_ACCEL_METHOD");

?>

