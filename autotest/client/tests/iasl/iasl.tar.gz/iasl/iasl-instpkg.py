#!/usr/bin/python
# Upgrade package to latest vertion in brew
__author__ = 'Yan Tian <tyan@redhat.com>'

import os

### setup brew env
os.system("wget http://porkchop.devel.redhat.com/rel-eng/brew/rhel/5/brew.repo -P /etc/yum.repos.d/ -q")
os.system("yum install brew -y -q")

import sys
import brew
import re
import xmlrpclib
from optparse import OptionParser

arch = os.uname()[4]
brew_link = "http://porkchop.devel.redhat.com/brewroot/packages/"

def _(args):
    """Stub function for translation"""
    return args

def error(msg=None, code=1):
    if msg:
        sys.stderr.write(msg + "\n")
        sys.stderr.flush()
    sys.exit(code)

def ensure_connection(session):
    try:
        ret = session.getAPIVersion()
    except xmlrpclib.ProtocolError:
        error(_("Error: Unable to connect to server"))

    if ret != brew.API_VERSION:
        print _("WARNING: The server is at API version %d and the client is at %d" % (ret, brew.API_VERSION))
    print "Connect to server successfully!\n"
    return True

if __name__ == "__main__":
    usage = _("Usage: upgrade-latest-brew-pkg.py pkg tag")
    parser = OptionParser(usage=usage)
    parser.disable_interspersed_args()
    parser.add_option("-d", "--debug", action="store_true", default=False, help=_("Show debugging output"))

    (options, args) = parser.parse_args()

    ## parse arguments
    opts = {}
    opts['debug'] = options.debug

    ## setup server connection
    session_opts = {'debug': opts['debug']}
    brewhub = brew.ClientSession("http://brewhub.devel.redhat.com/brewhub", session_opts)

    # just quick sanity check on the args before we connect to the server
    if len(args) < 1:
        error("You must specify package and tag. Usage: upgrade-latest-brew-pkg.py pkg tag \nSuch as: python upgrade-latest-brew-pkg.py libvirt dist-5E-U4-pending \nYou could check tag info for specified package in Brew website https://brewweb.devel.redhat.com/.")

    try:
        ## make sure we can connect to the server
        ensure_connection(brewhub)
        if options.debug:
            print "Successfully connected to hub"
    except (KeyboardInterrupt,SystemExit):
       pass
    except:
       if options.debug:
            raise
       else:
            exctype, value = sys.exc_info()[:2]
            rv = 1
            print "%s: %s" % (exctype, value)

    # validate the package
    pkg_info = brewhub.getPackage(args[0])
    if not pkg_info:
        parser.error(_("Unknown package: %s" % args[0]))

    # validate the tag
    tag_info = brewhub.getTag(args[1])
    if not tag_info:
        parser.error(_("Unknown tag: %s" % args[1]))

    pkg = args[0]
    tag = args[1]

    rpms = brewhub.getLatestRPMS(tag, pkg, arch, None, False)
    #print rpms

    if len(rpms) != 0:
	rpm = rpms[0]
	#print rpm
	brew_rpms = ''
	if len(rpm) != 0:
	    for i in range(len(rpm)):
		pkg_name = rpm[i]["name"]
		version = rpm[i]["version"]
		release = rpm[i]["release"]
		brew_rpm = brew_link + pkg + "/" + version + "/" + release + "/" + arch + "/" + pkg_name + "-" + version + "-" + release + "." + arch + ".rpm "
		brew_rpms = brew_rpms + brew_rpm
	else:
	    arch = "noarch"
	    pkg_name = rpms[1][0]["package_name"]
	    version = rpms[1][0]["version"]
	    release = rpms[1][0]["release"]
	    brew_rpms = brew_link + pkg + "/" + version + "/" + release + "/" + arch + "/" + pkg_name + "-" + version + "-" + release + "." + arch + ".rpm"
	#print brew_rpms

	### upgrade the package to latest version
	cmd = "rpm -Uvh " + brew_rpms
	#print cmd
	os.system(cmd)
