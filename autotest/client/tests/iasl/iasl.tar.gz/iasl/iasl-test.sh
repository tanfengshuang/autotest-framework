#!/bin/bash
# Filename: iasl-test.sh
##@ Summary: Run iasl command with all options.
##@ Description: Verify each of the option of iasl can works well.
##@ Maintainer:  Neil Zhang <nzhang@redhat.com>
##@ Created:     Wed May 6, 2009
##@ Updated:     Mon Jun 29, 2009
##@ Version:     1.0

CHECK_PKG=`rpm -qa | grep 'iasl'`
TEMP_DIR="tmp"
#LOG_DIR="logs"
LOG_DIR="result"
RES_FILE="result/result-summary.txt"
logFile="result/result.log"
group_num=0
process_num=0

result_count()
{
# $1: Test case
# $2: Case name
# $3: Command options
# $4: Command options' description
let process_num=$process_num+1
summary="[$2 $3][$4][test_process=$process_num/2109]"
end_time=`date +'%F %H:%M:%S'`
error_msg=`echo $1 | egrep '[^0] Errors|Could not'`

echo -ne "START\t$summary\t$start_time" | tee -a $logFile
if [ -z "$error_msg" ]; then
    pass_num=$((pass_num+1))
    result="PASS"
    echo -e "\nGOOD\tCompleted successfully" | tee -a $logFile
else
    fail_num=$((fail_num+1))
    result="FAIL"
    echo -e "\nERROR\t$error_msg" | tee -a $logFile
fi
echo -e "END\t$end_time" | tee -a $logFile
echo $line | tee -a $logFile
}

i=1
separator='-'
line=''
while [ $i -le 80 ]
do
    line=${line}${separator}
    i=$((i+1))
done

if [ -d asl ]; then
    ASL_LIST="asl/*"
else
    echo "No asl test sample for running."
    exit 1
fi

if [ -z "$CHECK_PKG" ]; then
    echo "No iASL package was installed."
    python iasl-instpkg.py iasl dist-5E-U4
fi

if [ -d $TEMP_DIR ]; then
    rm -rf $TEMP_DIR
    mkdir $TEMP_DIR
else
    mkdir $TEMP_DIR
fi

#if [ -d $LOG_DIR ]; then
#    rm -rf $LOG_DIR
#    mkdir $LOG_DIR
#else
#    mkdir $LOG_DIR
#fi

if [ -e $RES_FILE ]; then
    rm -f $RES_FILE
    touch $RES_FILE
else
    touch $RES_FILE
fi

if [ -e $logFile ]; then
    rm -f $logFile
    touch $logFile
else
    touch $logFile
fi

for ASL_FILE in $ASL_LIST
do
    ASL_NAME=`basename $ASL_FILE`
    ASL_PATH=`echo $ASL_FILE | awk -F'.' '{print $1}'`
    CASE=`echo $ASL_NAME | awk -F'.' '{print $1}'`
    CASE_DIR="$TEMP_DIR/$CASE"
    AML_FILE="$CASE_DIR/$CASE.aml"
    LOG_FILE="$LOG_DIR/$CASE.log"
    case_num=0
    pass_num=0
    fail_num=0

    mkdir -p $TEMP_DIR/$CASE

    group_num=$((group_num+1))
    echo -e "\n########## Test Group $group_num ##########\n" | tee -a $LOG_FILE $RES_FILE
    echo "~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    echo " General Output:" >> $LOG_FILE
    echo "~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -p <prefix> ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-p <prefix>" "Specify filename prefix for all output files (including .aml)"
    echo -n "CASE $case_num : [ -p <prefix> ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -vi ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -vi -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-vi" "Less verbose errors and warnings for use with IDEs"
    echo -n "CASE $case_num : [ -vi ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -vo ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl  -p ${CASE_DIR}/${CASE} -vo -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-vo" "Enable optimization comments"
    echo -n "CASE $case_num : [ -vo ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -vr ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -vr -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-vr" "Disable remarks"
    echo -n "CASE $case_num : [ -vr ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -vs ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -vs -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-vs" "Disable signon"
    echo -n "CASE $case_num : [ -vs ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -w1 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -w1 -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-w1" "Set warning reporting level 1"
    echo -n "CASE $case_num : [ -w1 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -w2 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -w2 -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-w2" "Set warning reporting level 2"
    echo -n "CASE $case_num : [ -w2 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE
 
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -w3 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -w3 -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-w3" "Set warning reporting level 3"
    echo -n "CASE $case_num : [ -w3 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo "~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    echo " AML Output Files:" >> $LOG_FILE
    echo "~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -sa ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -sa $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-sa" "Create AML in assembler source file (*.asm)"
    echo -n "CASE $case_num : [ -sa ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -sc ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -sc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-sc" " Create AML in C source file (*.c)"
    echo -n "CASE $case_num : [ -sc ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ia ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ia $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ia" "Create assembler include file (*.inc)"
    echo -n "CASE $case_num : [ -ia ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ic ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ic $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ic" "Create C include file (*.h)"
    echo -n "CASE $case_num : [ -ic ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ta ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ta $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ta" "Create AML in assembler hex table (*.hex)"
    echo -n "CASE $case_num : [ -ta ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE
    [ -e ${CASE_DIR}/${CASE}.hex ] && mv ${CASE_DIR}/${CASE}.hex ${CASE_DIR}/${CASE}_asm.hex
 
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -tc ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-tc" "Create AML in C hex table (*.hex)"
    echo -n "CASE $case_num : [ -tc ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE
    [ -e ${CASE_DIR}/${CASE}.hex ] && mv ${CASE_DIR}/${CASE}.hex ${CASE_DIR}/${CASE}_c.hex

    echo "~~~~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    echo " AML Code Generation:" >> $LOG_FILE
    echo "~~~~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -oa ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -oa -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-oa" "Disable all optimizations (compatibility mode)"
    echo -n "CASE $case_num : [ -oa ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -of ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -of -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-of" "Disable constant folding"
    echo -n "CASE $case_num : [ -of ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -oi ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -oi -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-oi" "Disable integer optimization to Zero/One/Ones"
    echo -n "CASE $case_num : [ -oi ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num: [ -on ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -on -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-on" "Disable named reference string optimization"
    echo -n "CASE $case_num : [ -on ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo "~~~~~~~~~~~" >> $LOG_FILE
    echo " Listings:" >> $LOG_FILE
    echo "~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -l ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -l $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-l" "Create mixed listing file (ASL source and AML) (*.lst)"
    echo -n "CASE $case_num : [ -l ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ln ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ln $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ln" "Create namespace file (*.nsp)"
    echo -n "CASE $case_num : [ -ln ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ls ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ls $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ls" "Create combined source file (expanded includes) (*.src)"
    echo -n "CASE $case_num : [ -ls ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo "~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    echo " AML Disassembler:" >> $LOG_FILE
    echo "~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -d ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -d $AML_FILE 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-d" "Disassemble or decode binary ACPI table to file (*.dsl)"
    echo -n "CASE $case_num : [ -d ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -dc ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -dc $AML_FILE 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-dc" "Disassemble AML and immediately compile it (Obtain DSDT from current system if no input file)"
    echo -n "CASE $case_num : [ -dc ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -e ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -d -e $AML_FILE 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-e" "Include ACPI table for external symbol resolution"
    echo -n "CASE $case_num : [ -e ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -2 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -d -2 $AML_FILE 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-2" "Emit ACPI 2.0 compatible ASL code"
    echo -n "CASE $case_num : [ -2 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -g ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -g 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-g" "Get ACPI tables and write to files (*.dat)"
    echo -n "CASE $case_num : [ -g ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo "~~~~~~~" >> $LOG_FILE
    echo " Help:" >> $LOG_FILE
    echo "~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -h ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -h 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-h" "Additional help and compiler debug options"
    echo -n "CASE $case_num : [ -h ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -hc ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -hc 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-hc" "Display operators allowed in constant expressions"
    echo -n "CASE $case_num : [ -hc ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -hr ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -hr 2>&1 | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-hr" "Display operators allowed in constant expressions"
    echo -n "CASE $case_num : [ -hr ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    echo " Compiler/Disassembler Debug Options:" >> $LOG_FILE
    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" >> $LOG_FILE
    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -bp ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -bp -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-bp" "Create compiler debug/trace file (*.txt) Types: Parse"
    echo -n "CASE $case_num : [ -bp ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -bt ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -bt -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-bt" "Create compiler debug/trace file (*.txt) Types: Tree"
    echo -n "CASE $case_num : [ -bt ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num: [ -bb ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -bb -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-bb" "Create compiler debug/trace file (*.txt) Types: Both"
    echo -n "CASE $case_num : [ -bb ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -f ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -f -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-f" "Ignore errors, force creation of AML output file(s)"
    echo -n "CASE $case_num : [ -f ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -c ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -c -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-c" "Parse only, no output generation"
    echo -n "CASE $case_num : [ -c ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -ot ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -ot -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-ot" "Display compile times"
    echo -n "CASE $case_num : [ -ot ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -x 0 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -x 0 -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-x 0" "Set debug level with 0 for trace output"
    echo -n "CASE $case_num : [ -x 0 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    case_num=$((case_num+1))
    echo -ne "***\n*** " >> $LOG_FILE
    echo "CASE $case_num : [ -x 255 ]" >> $LOG_FILE
    echo "***" >> $LOG_FILE
    start_time=`date +'%F %H:%M:%S'`
    run_case=`iasl -p ${CASE_DIR}/${CASE} -x 255 -tc $ASL_FILE | tee -a $LOG_FILE`
    result_count "$run_case" $CASE "-x 255" "Set debug level with 255 for trace output"
    echo -n "CASE $case_num : [ -x 255 ]  " >> $RES_FILE
    echo "------ $result ------" >> $RES_FILE

    echo -e "\n" >> $LOG_FILE $RES_FILE
    echo "=========================" >> $LOG_FILE >> $RES_FILE
    echo " Test Group $group_num: $CASE" >> $LOG_FILE >> $RES_FILE
    echo "=========================" >> $LOG_FILE >> $RES_FILE
    echo " Total tcs: $case_num" >> $LOG_FILE >> $RES_FILE
    echo " Pass tcs:  $pass_num" >> $LOG_FILE >> $RES_FILE
    echo " Fail tcs:  $fail_num" >> $LOG_FILE >> $RES_FILE
    echo -e "\n" >> $LOG_FILE $RES_FILE

done

echo "Result summary in file \"$RES_FILE\""
echo "Log files are saved in directory \"$LOG_DIR/\""
exit 0
